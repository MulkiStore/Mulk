const chalk = require("chalk")
const fs = require("fs")

  global.ownerNumber = "6283820103137@s.whatsapp.net""6285745286462@s.whatsapp.net"
  global.kontakOwner = "6283820103137"
  global.namaStore = "MULKSTORE"
  global.botName = "MulkBotz"
  global.ownerName = "Mulk"
  
  
  global.linkyt = "link chanel yt lu"
  global.linkig = "link akun ig lu"
  global.dana = "Scan qris di atas"
  global.sawer = "Scan qris di atas"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})